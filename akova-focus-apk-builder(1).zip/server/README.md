# Backend

Generated stub for akova-focus. Run with `node server/index.js` after wiring an Express server.