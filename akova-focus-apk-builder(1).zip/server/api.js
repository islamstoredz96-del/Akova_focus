

```js
// server/api.js

const express = require('express');
const router = express.Router();

// ============================================================
// MOCK DATA STORES (In-Memory)
// ============================================================

const stores = {
  users: new Map(),
  programs: new Map(),
  days: new Map(),
  tasks: new Map(),
  subtasks: new Map(),
  exceptions: new Map(),
  protectionSettings: new Map(),
  prayerSettings: new Map(),
  sleepSettings: new Map(),
  notificationSettings: new Map(),
  syncData: new Map(),
  progress: new Map(),
  sessions: new Map(),
  otps: new Map(),
};

// ============================================================
// UTILITY HELPERS
// ============================================================

const generateId = () => Math.random().toString(36).substring(2, 15);
const now = () => new Date().toISOString();

const getCurrentUser = (req) => {
  const sessionId = req.headers['x-session-id'];
  if (!sessionId) return null;
  const session = stores.sessions.get(sessionId);
  if (!session) return null;
  return stores.users.get(session.userId) || null;
};

const requireAuth = (req, res, next) => {
  const user = getCurrentUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  req.user = user;
  next();
};

const paginate = (items, page = 1, limit = 20) => {
  const start = (page - 1) * limit;
  return {
    items: items.slice(start, start + limit),
    page,
    limit,
    total: items.length,
    totalPages: Math.ceil(items.length / limit),
  };
};

// ============================================================
// AUTH ENDPOINTS
// ============================================================

/**
 * POST /api/auth/signup
 * Create a new user account with email and password.
 */
router.post('/auth/signup', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  // Check if user already exists
  for (const user of stores.users.values()) {
    if (user.email === email) {
      return res.status(409).json({ error: 'User with this email already exists' });
    }
  }

  const userId = generateId();
  const user = {
    id: userId,
    email,
    passwordHash: `hashed_${password}`, // In production, use bcrypt
    guest: false,
    createdAt: now(),
    lastLoginAt: now(),
  };

  stores.users.set(userId, user);

  // Create default settings
  stores.protectionSettings.set(userId, {
    id: generateId(),
    userId,
    level: 'standard',
    allowedApps: [],
    blockedApps: [],
    emergencyOverride: false,
    emergencyExpiresAt: null,
    protectionActive: false,
  });

  stores.prayerSettings.set(userId, {
    id: generateId(),
    userId,
    city: 'Cairo',
    latitude: 30.0444,
    longitude: 31.2357,
    calculationMethod: 'umm_qura',
    notificationsEnabled: true,
  });

  stores.sleepSettings.set(userId, {
    id: generateId(),
    userId,
    startTime: '22:00',
    endTime: '06:00',
    quietMode: true,
    autoFocus: true,
    blockAppsDuringSleep: false,
  });

  stores.notificationSettings.set(userId, {
    id: generateId(),
    userId,
    masterEnabled: true,
    taskEnabled: true,
    prayerEnabled: true,
    sleepEnabled: true,
    frequency: 'normal',
  });

  stores.progress.set(userId, {
    id: generateId(),
    userId,
    date: new Date().toISOString().split('T')[0],
    completedTasks: 0,
    missedTasks: 0,
    exceptions: 0,
    completionRate: 0,
    streak: 0,
    appFirstUsedDate: new Date().toISOString().split('T')[0],
  });

  const sessionId = generateId();
  stores.sessions.set(sessionId, { userId, createdAt: now() });

  res.status(201).json({
    user: { id: userId, email, guest: false, createdAt: user.createdAt },
    sessionId,
  });
});

/**
 * POST /api/auth/login
 * Authenticate an existing user and create a session.
 */
router.post('/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  let foundUser = null;
  for (const user of stores.users.values()) {
    if (user.email === email) {
      foundUser = user;
      break;
    }
  }

  if (!foundUser) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // In production, verify password hash
  if (foundUser.passwordHash !== `hashed_${password}`) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  foundUser.lastLoginAt = now();

  const sessionId = generateId();
  stores.sessions.set(sessionId, { userId: foundUser.id, createdAt: now() });

  res.json({
    user: {
      id: foundUser.id,
      email: foundUser.email,
      guest: foundUser.guest,
      createdAt: foundUser.createdAt,
      lastLoginAt: foundUser.lastLoginAt,
    },
    sessionId,
  });
});

/**
 * POST /api/auth/logout
 * End the current user session.
 */
router.post('/auth/logout', (req, res) => {
  const sessionId = req.headers['x-session-id'];

  if (sessionId && stores.sessions.has(sessionId)) {
    stores.sessions.delete(sessionId);
  }

  res.json({ message: 'Logged out successfully' });
});

/**
 * POST /api/auth/verify-email
 * Verify a user's email address with OTP.
 */
router.post('/auth/verify-email', (req, res) => {
  const { email, otp } = req.body;

  if (!email || !otp) {
    return res.status(400).json({ error: 'Email and OTP are required' });
  }

  const storedOtp = stores.otps.get(email);

  if (!storedOtp || storedOtp.code !== otp) {
    return res.status(400).json({ error: 'Invalid or expired OTP' });
  }

  if (new Date(storedOtp.expiresAt) < new Date()) {
    stores.otps.delete(email);
    return res.status(400).json({ error: 'OTP has expired' });
  }

  stores.otps.delete(email);

  // Mark user as verified
  for (const user of stores.users.values()) {
    if (user.email === email) {
      user.emailVerified = true;
      break;
    }
  }

  res.json({ message: 'Email verified successfully' });
});

/**
 * POST /api/auth/google
 * Authenticate with Google Sign-In via Credential Manager.
 */
router.post('/auth/google', (req, res) => {
  const { googleToken } = req.body;

  if (!googleToken) {
    return res.status(400).json({ error: 'Google token is required' });
  }

  // In production, verify the Google token with Google's API
  // For mock purposes, we'll simulate a successful verification
  const mockGoogleUser = {
    googleId: `google_${generateId()}`,
    email: `user_${generateId()}@gmail.com`,
    name: 'Google User',
  };

  // Check if user exists by Google ID or email
  let user = null;
  for (const u of stores.users.values()) {
    if (u.googleId === mockGoogleUser.googleId || u.email === mockGoogleUser.email) {
      user = u;
      break;
    }
  }

  if (!user) {
    const userId = generateId();
    user = {
      id: userId,
      email: mockGoogleUser.email,
      name: mockGoogleUser.name,
      googleId: mockGoogleUser.googleId,
      guest: false,
      createdAt: now(),
      lastLoginAt: now(),
    };
    stores.users.set(userId, user);
  }

  user.lastLoginAt = now();

  const sessionId = generateId();
  stores.sessions.set(sessionId, { userId: user.id, createdAt: now() });

  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      guest: user.guest,
      createdAt: user.createdAt,
    },
    sessionId,
  });
});

// ============================================================
// SYNC ENDPOINTS
// ============================================================

/**
 * POST /api/sync/push
 * Push local changes to the cloud with version and timestamp.
 */
router.post('/sync/push', requireAuth, (req, res) => {
  const { payload, version, lastLocalChangeAt } = req.body;
  const userId = req.user.id;

  if (!payload) {
    return res.status(400).json({ error: 'Payload is required' });
  }

  let syncRecord = stores.syncData.get(userId);

  if (!syncRecord) {
    syncRecord = {
      id: generateId(),
      userId,
      payload: {},
      version: 0,
      updatedAt: now(),
      lastLocalChangeAt: now(),
    };
  }

  // Merge payload with existing data
  const mergedPayload = { ...syncRecord.payload, ...payload };
  syncRecord.payload = mergedPayload;
  syncRecord.version = (version || syncRecord.version) + 1;
  syncRecord.updatedAt = now();
  syncRecord.lastLocalChangeAt = lastLocalChangeAt || now();

  stores.syncData.set(userId, syncRecord);

  res.json({
    success: true,
    version: syncRecord.version,
    updatedAt: syncRecord.updatedAt,
  });
});

/**
 * GET /api/sync/pull
 * Pull remote changes and merge with local state.
 */
router.get('/sync/pull', requireAuth, (req, res) => {
  const userId = req.user.id;
  const { since } = req.query;

  const syncRecord = stores.syncData.get(userId);

  if (!syncRecord) {
    return res.json({
      payload: {},
      version: 0,
      updatedAt: now(),
      hasChanges: false,
    });
  }

  const hasChanges = since ? new Date(syncRecord.updatedAt) > new Date(since) : true;

  res.json({
    payload: syncRecord.payload,
    version: syncRecord.version,
    updatedAt: syncRecord.updatedAt,
    hasChanges,
  });
});

// ============================================================
// AI ENDPOINTS
// ============================================================

/**
 * POST /api/ai/generate-program
 * Generate a complete program using the Gemini model.
 */
router.post('/ai/generate-program', requireAuth, (req, res) => {
  const { goals, preferences, duration } = req.body;

  if (!goals || !preferences) {
    return res.status(400).json({ error: 'Goals and preferences are required' });
  }

  // Mock AI response - in production, call Gemini API
  const programId = generateId();
  const program = {
    id: programId,
    userId: req.user.id,
    name: `Custom Program - ${new Date().toLocaleDateString()}`,
    active: true,
    paused: false,
    pauseExpiresAt: null,
    createdAt: now(),
    updatedAt: now(),
  };

  const days = [];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  for (let i = 0; i < (duration || 7); i++) {
    const dayId = generateId();
    const day = {
      id: dayId,
      programId,
      name: dayNames[i % 7],
      order: i + 1,
      paused: false,
      pauseExpiresAt: null,
    };
    days.push(day);

    // Generate tasks for each day
    const tasks = generateMockTasks(dayId, i);
    tasks.forEach((task) => stores.tasks.set(task.id, task));
  }

  stores.programs.set(programId, program);
  days.forEach((day) => stores.days.set(day.id, day));

  res.json({
    program,
    days,
    message: 'Program generated successfully',
  });
});

/**
 * POST /api/ai/refine-program
 * Refine an existing program based on user feedback.
 */
router.post('/ai/refine-program', requireAuth, (req, res) => {
  const { programId, feedback } = req.body;

  if (!programId || !feedback) {
    return res.status(400).json({ error: 'Program ID and feedback are required' });
  }

  const program = stores.programs.get(programId);
  if (!program) {
    return res.status(404).json({ error: 'Program not found' });
  }

  // Mock refinement - in production, call Gemini API
  const refinedProgram = {
    ...program,
    name: `Refined: ${program.name}`,
    updatedAt: now(),
  };

  stores.programs.set(programId, refinedProgram);

  res.json({
    program: refinedProgram,
    message: 'Program refined based on feedback',
  });
});

/**
 * POST /api/ai/modify-program
 * Modify specific aspects of a program.
 */
router.post('/ai/modify-program', requireAuth, (req, res) => {
  const { programId, modifications } = req.body;

  if (!programId || !modifications) {
    return res.status(400).json({ error: 'Program ID and modifications are required' });
  }

  const program = stores.programs.get(programId);
  if (!program) {
    return res.status(404).json({ error: 'Program not found' });
  }

  const modifiedProgram = {
    ...program,
    ...modifications,
    updatedAt: now(),
  };

  stores.programs.set(programId, modifiedProgram);

  res.json({
    program: modifiedProgram,
    message: 'Program modified successfully',
  });
});

/**
 * POST /api/ai/suggest-subtasks
 * Suggest subtasks for a given task.
 */
router.post('/ai/suggest-subtasks', requireAuth, (req, res) => {
  const { taskId, context } = req.body;

  if (!taskId) {
    return res.status(400).json({ error: 'Task ID is required' });
  }

  const task = stores.tasks.get(taskId);
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }

  // Mock AI suggestions based on task title
  const mockSubtasks = generateMockSubtasks(task.title);

  res.json({
    taskId,
    suggestions: mockSubtasks,
  });
});

/**
 * POST /api/ai/organize-time
 * Reorganize the daily schedule for optimal time usage.
 */
router.post('/ai/organize-time', requireAuth, (req, res) => {
  const { programId, date } = req.body;

  if (!programId) {
    return res.status(400).json({ error: 'Program ID is required' });
  }

  const program = stores.programs.get(programId);
  if (!program) {
    return res.status(404).json({ error: 'Program not found' });
  }

  // Get all days for the program
  const programDays = Array